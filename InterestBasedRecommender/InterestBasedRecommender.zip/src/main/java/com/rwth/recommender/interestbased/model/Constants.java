/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.rwth.recommender.interestbased.model;

/**
 *
 * @author Marco
 */
public class Constants {
    
    public static int MINIMUM_VALUE_TO_BE_GOOD_INTEREST = 10;
    
    public static int MINIMAL_SCORE_TO_BE_SIMILAR_USERS = 10;
    
}
