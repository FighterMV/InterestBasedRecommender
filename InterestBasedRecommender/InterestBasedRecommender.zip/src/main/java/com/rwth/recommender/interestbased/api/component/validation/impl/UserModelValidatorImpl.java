/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.rwth.recommender.interestbased.api.component.validation.impl;

import com.rwth.recommender.interestbased.api.component.validation.UserModelValidator;
import org.springframework.stereotype.Component;

/**
 *
 * @author Marco
 */
@Component
public class UserModelValidatorImpl implements UserModelValidator{

    @Override
    public Boolean isValidModel(String userModel) {
	//!TODO Implement
	throw new UnsupportedOperationException("Not supported yet.");
    }
    
}
